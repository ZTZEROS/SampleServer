#pragma once

class JW2InnerServer
{
	friend class JW2InnerClient;
	friend class JW2OuterServer;

private:
	JW2ServerSession SS; //JW2SS
	JW2ClientSessionV CSV; //JW2CSV
	JW2SubThreadV STV; //SUB_THREAD_V;



	HANDLE ACP; //AcceptCompletionPort; 
	HANDLE CCP; //ConnectCompletionPort;

	HANDLE RCP; //ReceiveCompletionPort;
	HANDLE UCP; //UpdateCompletionPort;
	HANDLE SCP; //SendCompletionPort;
	HANDLE WCP; //WokrCompletionPort;
	
	HANDLE DCP; //DisconnectCompletionPort;



	JW2InnerServer* SelfInstanceAddress;

	wstring IP_Address;
	UINT Port;
	UINT MaximumClientCount;
	UINT RecieveThreadCount;
	UINT SendThreadCount;
	UINT WorkThreadCount;

public:
	JW2InnerServer();
	virtual ~JW2InnerServer();

	bool Initialize();
	bool Update();
	bool Render();
	bool Terminalize();



	static unsigned int WINAPI AcceptClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI ConnectClient(LPVOID selfInstanceAddress);
	
	static unsigned int WINAPI ReceiveClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI UpdateClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI SendClient(LPVOID selfInstanceAddress);

	static unsigned int WINAPI WorkClient(LPVOID selfInstanceAddress);
	
	static unsigned int WINAPI DisconnectClient(LPVOID selfInstanceAddress);



	unsigned int AccpetClient();
	unsigned int ConnectClient();

	unsigned int ReceiveClient();
	unsigned int UpdateClient();
	unsigned int SendClient();
	
	unsigned int WorkClient();
	
	unsigned int DisconnectClient();



	unsigned int PostAccept(UINT64 sessionKey);
	unsigned int PostConnect(UINT64 sessionKey);
	
	unsigned int PostReceive(UINT64 sessionKey);
	unsigned int PostUpdate(UINT64 sessionKey);
	unsigned int PostSend(UINT64 sessionKey);

	unsigned int PostDisconnect(UINT64 sessionKey);
};