#pragma once

enum JW2_LOCAL_CONSTANT
{
	FREE_WIZARD_NET_SERVER_PORT = 9624,
	WIZARD_NET_SERVER_PORT = 9913,
	JW2_PEER_TO_PEER_PORT = 9922,

	JW2_SESSION_KEY_BIT_COUNT = 64,
	JW2_CLIENT_INDEX_BIT_COUNT = 32,
	JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT = JW2_SESSION_KEY_BIT_COUNT - JW2_CLIENT_INDEX_BIT_COUNT,

	JW2_SERVER_WSABUF_COUNT = 256,
	JW2_CLIENT_WSABUF_COUNT = 256,

	JW2_CLIENT_SET_COUNT = 256,
	JW2_CLIENT_COUNT = 64,
	TOTAL_JW2_CLIENT_COUNT = JW2_CLIENT_SET_COUNT * JW2_CLIENT_COUNT,

	JW2_LOCAL_CONSTANT_COUNT
};

enum JW2_SUB_THREAD_INDEX
{
	JW2_SUB_THREAD_ACCEPT,
	JW2_SUB_THREAD_CONNECT,

	JW2_SUB_THREAD_RECEIVE,
	JW2_SUB_THREAD_UPDATE,
	JW2_SUB_THREAD_SEND,
	
	JW2_SUB_THREAD_WORK,
	
	JW2_SUB_THREAD_DISCONNECT,

	JW2_SUB_THREAD_COUNT
};

enum JW2_CLIENT_PHASE_INDEX
{
	JW2_CLIENT_PHASE_ACCEPT,
	JW2_CLIENT_PHASE_CONNECT,

	JW2_CLIENT_PHASE_RECEIVE,
	JW2_CLIENT_PHASE_UPDATE,
	JW2_CLIENT_PHASE_SEND,
	
	JW2_CLIENT_PHASE_WORK,

	JW2_CLIENT_PHASE_DISCONNECT,
	
	JW2_CLIENT_PHASE_COUNT
};

enum JW2_INNER_CLIENT_SUB_THREAD_INDEX
{
	JW2_INNER_CLIENT_SUB_THREAD_COUNT
};

enum JW2_INNER_SERVER_SUB_THREAD_INDEX
{
	JW2_INNER_SERVER_SUB_THREAD_ACCEPT,
	JW2_INNER_SERVER_SUB_THREAD_CONNECT,

	JW2_INNER_SERVER_SUB_THREAD_RECEIVE,
	JW2_INNER_SERVER_SUB_THREAD_UPDATE,
	JW2_INNER_SERVER_SUB_THREAD_SEND,

	JW2_INNER_SERVER_SUB_THREAD_WORK,

	JW2_INNER_SERVER_SUB_THREAD_DISCONNECT,

	JW2_INNER_SERVER_SUB_THREAD_COUNT
};

enum JW2_OUTER_SERVER_SUB_THREAD_INDEX
{
	JW2_OUTER_SERVER_SUB_THREAD_ACCEPT,
	JW2_OUTER_SERVER_SUB_THREAD_CONNECT,

	JW2_OUTER_SERVER_SUB_THREAD_RECEIVE,
	JW2_OUTER_SERVER_SUB_THREAD_UPDATE,
	JW2_OUTER_SERVER_SUB_THREAD_SEND,

	JW2_OUTER_SERVER_SUB_THREAD_WORK,

	JW2_OUTER_SERVER_SUB_THREAD_DISCONNECT,

	JW2_OUTER_SERVER_SUB_THREAD_COUNT
};

enum JW2_PACKET_INDEX
{
	JW2_PACKET_COUNT
};



#pragma pack(push, 1)

struct JW2PacketHeader
{
	DWORD BodySize;
	DWORD CryptoCode;
	DWORD CheckSum;
};

struct JW2PacketBody
{

};

struct JW2PacketTrailer
{

};

struct JW2Packet
{
	JW2PacketHeader Header;
	JW2PacketBody Body;
	JW2PacketTrailer Trailer;
};

#pragma pack(pop)



struct JW2ServerSession : public ServerSession
{
	OVERLAPPED OverlappedReceiving;
	OVERLAPPED OverlappedSending;

	ByteQueue ReceiveBQ;
	ByteQueue SendBQ;

	Queue<SerialByteDoubleEndedQueue*> ReceiveQ;
	Queue<SerialByteDoubleEndedQueue*> SendQ;

	SerialByteQueue CommandSBQ;

	SRWLOCK Lock;
};

struct JW2ClientSession : public ClientSession
{
	OVERLAPPED OverlappedReceiving;
	OVERLAPPED OverlappedSending;

	ByteQueue ReceiveBQ;
	ByteQueue SendBQ;

	Queue<SerialByteDoubleEndedQueue*> ReceiveQ;
	Queue<SerialByteDoubleEndedQueue*> SendQ;

	JW2_CLIENT_PHASE_INDEX CurrentPhase;

	SRWLOCK Lock;
};

struct JW2SubThread : public CommonSubThread
{

};

typedef vector<JW2ClientSession> JW2ClientSessionV;
typedef vector<JW2ClientSession>::iterator JW2ClientSessionVI;

typedef vector<JW2SubThread> JW2SubThreadV;
typedef vector<JW2SubThread>::iterator JW2SubThreadVi;

typedef vector<HANDLE> HANDLE_V;
typedef vector<HANDLE>::iterator HANDLE_VI;