#pragma once

class JW2InnerClient
{
private:

public:

};
