#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2InnerClient.h"
#include "JW2InnerServer.h"
//#include "JW2OuterClient.h"
#include "JW2OuterServer.h"
#include "JW2Server.h"

JW2InnerClient jw2InnerClient;
JW2InnerServer jw2InnerServer;
//JW2OuterClient jw2OuterClient;
JW2OuterServer jw2OuterServer;

int ExecuteJW2Server(int argumentCount, char* argumentVector[])
{
	//JW2InnerClient jw2InnerClient;
	//JW2InnerServer jw2InnerServer;
	////JW2OuterClient jw2OuterClient;
	//JW2OuterServer jw2OuterServer;

	//Initialize:
	{
		TIMER.Initialize();

		jw2InnerClient;
		jw2InnerServer.Initialize();
		jw2OuterServer.Initialize();
	}

	
	
	{
		while(1)
		{
			//Update:
			{
				//TIMER.Update();

				jw2InnerClient;
				jw2InnerServer.Update();
				jw2OuterServer.Update();
			}

			//Render:
			{
				//TIMER.Render();

				jw2InnerClient;
				jw2InnerServer.Render();
				jw2OuterServer.Render();
			}

			Sleep(10);
		}
	}

	//Terminalize:
	{
		TIMER.Termimalize();

		jw2InnerClient;
		jw2InnerServer.Terminalize();
		jw2OuterServer.Terminalize();
	}

	return 0;
}

//int APIENTRY ExecuteJW2Server(_In_ HINSTANCE instanceHandle, _In_opt_ HINSTANCE previousInstanceHandle, _In_ LPSTR lpCommandLine, _In_ int nCommandShow)
//{
//
//
//	return 0;
//}