#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2InnerServer.h"

unsigned int WINAPI JW2InnerServer::AcceptClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->AccpetClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::ConnectClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->ConnectClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::ReceiveClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->ReceiveClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::UpdateClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->UpdateClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::SendClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->SendClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::WorkClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->WorkClient();

	return 0;
}

unsigned int WINAPI JW2InnerServer::DisconnectClient(LPVOID selfInstanceAddress)
{
	JW2InnerServer* jw2InnerServerAddress;

	jw2InnerServerAddress = (JW2InnerServer*)selfInstanceAddress;
	jw2InnerServerAddress->DisconnectClient();

	return 0;
}