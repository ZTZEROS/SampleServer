#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2InnerServer.h"

unsigned int JW2InnerServer::PostAccept(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2InnerServer::PostConnect(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2InnerServer::PostReceive(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2InnerServer::PostUpdate(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2InnerServer::PostSend(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2InnerServer::PostDisconnect(UINT64 sessionKey)
{
	return 0;
}