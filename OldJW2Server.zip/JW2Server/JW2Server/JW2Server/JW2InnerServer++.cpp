#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2InnerServer.h"

unsigned int JW2InnerServer::AccpetClient()
{
	return 0;
}

unsigned int JW2InnerServer::ConnectClient()
{
	return 0;
}

unsigned int JW2InnerServer::ReceiveClient()
{
	return 0;
}

unsigned int JW2InnerServer::UpdateClient()
{
	return 0;
}

unsigned int JW2InnerServer::SendClient()
{
	return 0;
}

unsigned int JW2InnerServer::WorkClient()
{
	return 0;
}

unsigned int JW2InnerServer::DisconnectClient()
{
	return 0;
}