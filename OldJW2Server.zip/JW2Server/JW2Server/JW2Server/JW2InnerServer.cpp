#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2InnerServer.h"

JW2InnerServer::JW2InnerServer() {}
JW2InnerServer::~JW2InnerServer() {}

bool JW2InnerServer::Initialize()
{


	return 0;
}

bool JW2InnerServer::Update()
{


	return 0;
}

bool JW2InnerServer::Render()
{


	return 0;
}

bool JW2InnerServer::Terminalize()
{


	return 0;
}