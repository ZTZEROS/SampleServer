#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2OuterServer.h"

unsigned int JW2OuterServer::AccpetClient()
{
	JW2ClientSession clientSession;
	INT addressLength;
	
	UINT sessionIndex;
	UINT currentAcceptionCount;
	UINT64 sessionKey;

	addressLength = sizeof(clientSession.Address);
	sessionIndex = 0xffffffff;
	currentAcceptionCount = 0;
	sessionKey = 0xffffffffffffffff;

	while (SUB_THREAD_ON)
	{
		clientSession.Socket = WSAAccept(SS.Socket, (SOCKADDR*)&clientSession.Address, &addressLength, nullptr, NULL);
		//CHECK_INVALID_SOCKET(clientSession.Socket);
		
		IF_INVALID_SOCKET(clientSession.Socket)
		ELSE
		{
			while (1)
			{
				++sessionIndex;

				if (sessionIndex < CSV.size());
				else sessionIndex = 0;

				if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_ACCEPT)
				{
					++currentAcceptionCount; //InterlockedIncrement(&currentAcceptionCount);
					sessionKey = sessionIndex;
					sessionKey <<= JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;
					sessionKey += currentAcceptionCount;

					IF_NULL(CreateIoCompletionPort((HANDLE)clientSession.Socket, WCP, sessionKey, NULL))
						ELSE
					{
						CSV[sessionIndex].Socket = clientSession.Socket;
						CSV[sessionIndex].Address = clientSession.Address;
						CSV[sessionIndex].Key = sessionKey;
						CSV[sessionIndex].Index = sessionIndex;
						CSV[sessionIndex].Connected = 1;
						CSV[sessionIndex].Receivable = 1;
						CSV[sessionIndex].Sendable = 1;

						CSV[sessionIndex].ReceiveCount = 1;
						//InterlockedIncrement();
						//InterlockedExchange();
						CSV[sessionIndex].SendCount = 0;

						ZeroMemory(&CSV[sessionIndex].OverlappedReceiving, sizeof(CSV[sessionIndex].OverlappedReceiving));
						ZeroMemory(&CSV[sessionIndex].OverlappedSending, sizeof(CSV[sessionIndex].OverlappedSending));

						//CSV[sessionIndex].ReceiveBQ.Initialize();
						//CSV[sessionIndex].SendBQ.Initialize();
						//CSV[sessionIndex].ReceiveQ.Initialize();
						//CSV[sessionIndex].SendQ.Initialize();

						InitializeSRWLock(&CSV[sessionIndex].Lock);

						CSV[sessionIndex].CurrentPhase = JW2_CLIENT_PHASE_UPDATE;
						
						//{
						//	//PostQueuedCompletionStatus(RCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedReceiving);
						//	//PostQueuedCompletionStatus(SCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedReceiving);
						//
						//	PostQueuedCompletionStatus(WCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedReceiving);
						//}

						{
							DWORD flag;
							INT result;
						
							flag = 0;
							result = CSV[sessionIndex].ReceiveBQ.WSAReceive(WSARecv, CSV[sessionIndex].Socket, &flag, &CSV[sessionIndex].OverlappedReceiving);
						}
					}

					break;
				}
			}
		}
	}

	return 0;
}

unsigned int JW2OuterServer::ConnectClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(CCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{

		}
		else
		{

		}
	}

	return 0;
}

unsigned int JW2OuterServer::ReceiveClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(RCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{
			sessionKey = completionKey;
			sessionIndex = sessionKey >> JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;

			if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_UPDATE)
			{
				unsigned int currentSize;
				unsigned char packet[1024];

				currentSize = CSV[sessionIndex].ReceiveBQ.GetCurrentSize();

				CSV[sessionIndex].ReceiveBQ.Dequeue((char*)packet, transferredSize);
				
				FOR(i, currentSize / 16 + 1)
				{
					printf("%02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						" %02x"
						CRLF
						,
						packet[i * 16 + 0],
						packet[i * 16 + 1],
						packet[i * 16 + 2],
						packet[i * 16 + 3],
						packet[i * 16 + 4],
						packet[i * 16 + 5],
						packet[i * 16 + 6],
						packet[i * 16 + 7],
						packet[i * 16 + 8],
						packet[i * 16 + 9],
						packet[i * 16 + 10],
						packet[i * 16 + 11],
						packet[i * 16 + 12],
						packet[i * 16 + 13],
						packet[i * 16 + 14],
						packet[i * 16 + 15]
						);
				}

				PostQueuedCompletionStatus(UCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedSending);
			}
		}
		else
		{

		}
	}

	return 0;
}

unsigned int JW2OuterServer::UpdateClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(UCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{
			sessionKey = completionKey;
			sessionIndex = sessionKey >> JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;

			if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_UPDATE)
			{
				while (1)
				{
					SerialByteDoubleEndedQueue* packetAddress;

					packetAddress = PACKET_SBDEQ_TLP.Allocate();

					packetAddress->Initialize();

					unsigned int headerA;
					unsigned int headerB;
					unsigned int packetSize;
					unsigned char checksum;

					char body[256];

					headerA = 0xabcdef;
					headerB = 0xfedcba;
					packetSize = 128;

					checksum = 0;

					//scanf_s("%d", &headerA);
					//scanf_s("%d", &headerB);
					//scanf_s("%d", &packetSize);
					//scanf_s("%d", &checksum);
					//
					//FOR(i, packetSize - 13)
					//{
					//	scanf_s("%c", &body[i]);
					//}

					*packetAddress << headerA;
					*packetAddress << headerB;
					*packetAddress << packetSize;
					*packetAddress << checksum;

					FOR(i, packetSize - 13)
					{
						body[i] = i;
						*packetAddress << body[i];
					}

					packetAddress->IncreaseReferenceCount();
					CSV[sessionIndex].SendQ.Enqueue(packetAddress);

					++CSV[sessionIndex].SendCount;
					PostQueuedCompletionStatus(SCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedSending);

					Sleep(10);
				}

				//PostQueuedCompletionStatus(SCP, NULL, sessionKey, &CSV[sessionIndex].OverlappedSending);
			}
		}
		else
		{

		}
	}

	return 0;
}

unsigned int JW2OuterServer::SendClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(SCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{
			sessionKey = completionKey;
			sessionIndex = sessionKey >> JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;

			if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_UPDATE)
			{
				PostQueuedCompletionStatus(WCP, NULL, CSV[sessionIndex].Key, &CSV[sessionIndex].OverlappedSending);
			}
		}
		else
		{

		}
	}

	return 0;
}

unsigned int JW2OuterServer::WorkClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(WCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{
			sessionKey = completionKey;
			sessionIndex = sessionKey >> JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;

			if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_UPDATE)
			{
				//Receive
				if (&CSV[sessionIndex].OverlappedReceiving == overlapped)
				{
					ZeroMemory(&CSV[sessionIndex].OverlappedReceiving, sizeof(CSV[sessionIndex].OverlappedReceiving));

					if(transferredSize)
					{
						UINT receivedSize;

						receivedSize = transferredSize;

						CSV[sessionIndex].ReceiveBQ.IncreaseCurrentSize(receivedSize);

						//prepare ReceiveBQ capacity over

						PostQueuedCompletionStatus(RCP, transferredSize, sessionKey, &CSV[sessionIndex].OverlappedReceiving);
					}

					++CSV[sessionIndex].ReceiveCount;

					result = CSV[sessionIndex].ReceiveBQ.WSAReceive(WSARecv, CSV[sessionIndex].Socket, &flag, &CSV[sessionIndex].OverlappedReceiving);
					if (result == SOCKET_ERROR)
					{
						if (WSAGetLastError() == WSA_IO_PENDING);
						else
						{
							--CSV[sessionIndex].ReceiveCount;
						}
					}

					--CSV[sessionIndex].ReceiveCount;
				}

				//Send
				if (&CSV[sessionIndex].OverlappedSending == overlapped)
				{
					if (transferredSize)
					{
						UINT sendedSize;

						sendedSize = transferredSize;

						while (sendedSize)
						{
							SerialByteDoubleEndedQueue* sendedPacketSBDEQ_Address;

							sendedPacketSBDEQ_Address = CSV[sessionIndex].SendQ.Dequeue();

							sendedSize -= sendedPacketSBDEQ_Address->GetCurrentSize();

							if (!sendedPacketSBDEQ_Address->DecreaseReferenceCount())
							{
								InterlockedDecrement(&CURRENT_SBDEQ_COUNT);
								InterlockedIncrement(&DEALLOCATED_SBDEQ_COUNT);

								sendedPacketSBDEQ_Address->Terminalize();
								PACKET_SBDEQ_TLP.Deallocate(sendedPacketSBDEQ_Address);
							}
						}
					}

					{
						WSABUF sendingWSABUF_A[JW2_SERVER_WSABUF_COUNT];
						UINT sendingWSABUF_Count;

						sendingWSABUF_Count = CSV[sessionIndex].SendQ.GetCurrentCount();
						if (JW2_SERVER_WSABUF_COUNT < sendingWSABUF_Count) sendingWSABUF_Count = JW2_SERVER_WSABUF_COUNT;
						//sendingWSABUF_Count = CSV[sessionIndex].SendQ.GetCurrentCount() % JW2_SERVER_WSABUF_COUNT;

						if (sendingWSABUF_Count)
						{
							FOR(i, sendingWSABUF_Count)
							{
								SerialByteDoubleEndedQueue* sendingPacketSBDEQ_Address;
								
								sendingPacketSBDEQ_Address = CSV[sessionIndex].SendQ.Peek(i);

								sendingWSABUF_A[i].buf = sendingPacketSBDEQ_Address->GetLeftEndAddress();
								sendingWSABUF_A[i].len = sendingPacketSBDEQ_Address->GetCurrentSize();
							}

							++CSV[sessionIndex].SendCount;

							result = WSASend(CSV[sessionIndex].Socket, sendingWSABUF_A, sendingWSABUF_Count, nullptr, flag, &CSV[sessionIndex].OverlappedSending, nullptr);
							if (result == SOCKET_ERROR)
							{
								if (WSAGetLastError() == WSA_IO_PENDING);
								else
								{
									--CSV[sessionIndex].SendCount;
								}
							}
						}
						else InterlockedExchange(&CSV[sessionIndex].Sendable, 1);
					}

					--CSV[sessionIndex].SendCount;
				}

				//ConnectionCheck
				if (!CSV[sessionIndex].ReceiveCount && !CSV[sessionIndex].SendCount)
				{
					if (InterlockedExchange(&CSV[sessionIndex].Connected, 0) && CSV[sessionIndex].Key == sessionKey)
					{
						CSV[sessionIndex].CurrentPhase = JW2_CLIENT_PHASE_DISCONNECT;

						PostQueuedCompletionStatus(DCP, NULL, CSV[sessionIndex].Key, overlapped);
					}

					//PostDisconnect(CSV[sessionIndex].Key);
				}
			}
		}
		else
		{
		if (GetLastError() == ERROR_ABANDONED_WAIT_0) break;
		
		if (completionKey || transferredSize) continue;
		else break;
		}
	}

	return 0;
}

unsigned int JW2OuterServer::DisconnectClient()
{
	DWORD transferredSize;
	ULONG_PTR completionKey;
	LPOVERLAPPED overlapped;

	UINT64 sessionKey;
	UINT sessionIndex;

	DWORD flag;
	INT result;

	flag = 0;

	while (SUB_THREAD_ON)
	{
		overlapped = nullptr;

		GetQueuedCompletionStatus(WCP, &transferredSize, &completionKey, &overlapped, INFINITE);

		if (overlapped)
		{
			sessionKey = completionKey;
			sessionIndex = sessionKey >> JW2_CLIENT_INDEX_SHIFTED_BIT_COUNT;

			if (CSV[sessionIndex].CurrentPhase == JW2_CLIENT_PHASE_DISCONNECT)
			{
				UINT sendQ_CurrentCount;

				//process remained datum
				{

				}

				closesocket(CSV[sessionIndex].Socket);

				CSV[sessionIndex].Socket = INVALID_SOCKET;
				CSV[sessionIndex].Address;

				CSV[sessionIndex].Key = 0xffffffffffffffff;
				CSV[sessionIndex].Index = 0xffffffff;

				CSV[sessionIndex].Connected = 0;
				CSV[sessionIndex].Receivable = 0;
				CSV[sessionIndex].Sendable = 0;
				CSV[sessionIndex].ReceiveCount = 0;
				CSV[sessionIndex].SendCount = 0;

				ZeroMemory(&CSV[sessionIndex].OverlappedReceiving, sizeof(CSV[sessionIndex].OverlappedReceiving));
				ZeroMemory(&CSV[sessionIndex].OverlappedSending, sizeof(CSV[sessionIndex].OverlappedSending));

				sendQ_CurrentCount = CSV[sessionIndex].SendQ.GetCurrentCount();

				FOR(i, sendQ_CurrentCount)
				{
					SerialByteDoubleEndedQueue* sendedPacketSBDEQ_Address;

					sendedPacketSBDEQ_Address = CSV[sessionIndex].SendQ.Dequeue();

					if (!sendedPacketSBDEQ_Address->DecreaseReferenceCount())
					{
						InterlockedDecrement(&CURRENT_SBDEQ_COUNT);
						InterlockedIncrement(&DEALLOCATED_SBDEQ_COUNT);

						sendedPacketSBDEQ_Address->Terminalize();
						PACKET_SBDEQ_TLP.Deallocate(sendedPacketSBDEQ_Address);
					}
				}

				CSV[sessionIndex].ReceiveBQ.Terminalize();
				CSV[sessionIndex].SendBQ.Terminalize();
				CSV[sessionIndex].ReceiveQ.Terminalize();
				CSV[sessionIndex].SendQ.Terminalize();

				CSV[sessionIndex].CurrentPhase = JW2_CLIENT_PHASE_ACCEPT;
			}
		}
		else
		{
			if (GetLastError() == ERROR_ABANDONED_WAIT_0) break;

			if (completionKey || transferredSize) continue;
			else break;
		}
	}

	return 0;
}