#pragma once

int ExecuteJW2Server(int argumentCount, char* argumentVector[]);
//int APIENTRY ExecuteJW2Server(_In_ HINSTANCE instanceHandle, _In_opt_ HINSTANCE previousInstanceHandle, _In_ LPSTR lpCommandLine, _In_ int nCommandShow);