#pragma once

class JW2OuterServer
{
	friend class JW2InnerClient;
	friend class JW2InnerServer;

private:
	JW2ServerSession SS; //JW2SS
	JW2ClientSessionV CSV; //JW2CSV
	
	JW2SubThreadV STV; //SubThreadV //SUB_THREAD_V
	
	BOOL SUB_THREAD_ON;
	UINT CURRENT_ACCEPTION_COUNT;



	HANDLE ACP; //AcceptCompletionPort; 
	HANDLE CCP; //ConnectCompletionPort;

	HANDLE RCP; //ReceiveCompletionPort;
	HANDLE UCP; //UpdateCompletionPort;
	HANDLE SCP; //SendCompletionPort;
	HANDLE WCP; //WokrCompletionPort;

	HANDLE DCP; //DisconnectCompletionPort;



	JW2OuterServer* SelfInstanceAddress;

	wstring IP_Address;
	UINT Port;
	UINT MaximumClientCount;
	UINT ReceiveThreadCount;
	UINT SendThreadCount;
	UINT WorkThreadCount;

protected:
	ThreadLocalPool<SerialByteDoubleEndedQueue> PACKET_SBDEQ_TLP;

	UINT CURRENT_SBDEQ_COUNT;
	UINT ALLOCATED_SBDEQ_COUNT;
	UINT DEALLOCATED_SBDEQ_COUNT;
	
public:
	JW2OuterServer();
	virtual ~JW2OuterServer();

	bool Initialize(); //Initiate
	bool Update();
	bool Render();
	bool Terminalize(); //Terminate



	static unsigned int WINAPI AcceptClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI ConnectClient(LPVOID selfInstanceAddress);

	static unsigned int WINAPI ReceiveClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI UpdateClient(LPVOID selfInstanceAddress);
	static unsigned int WINAPI SendClient(LPVOID selfInstanceAddress);

	static unsigned int WINAPI WorkClient(LPVOID selfInstanceAddress);

	static unsigned int WINAPI DisconnectClient(LPVOID selfInstanceAddress);



	unsigned int AccpetClient();
	unsigned int ConnectClient();

	unsigned int ReceiveClient();
	unsigned int UpdateClient();
	unsigned int SendClient();

	unsigned int WorkClient();

	unsigned int DisconnectClient();


	unsigned int ReceivePacket(UINT64 sessionKey, SerialByteDoubleEndedQueue* receivedPacketSBDEQ_Address);
	unsigned int SendPacket(UINT64 sessionKey, SerialByteDoubleEndedQueue* sendingPacketSBDEQ_Address);


	unsigned int PostAccept(UINT64 sessionKey);
	unsigned int PostConnect(UINT64 sessionKey);

	unsigned int PostReceive(UINT64 sessionKey);
	unsigned int PostUpdate(UINT64 sessionKey);
	unsigned int PostSend(UINT64 sessionKey);

	unsigned int PostDisconnect(UINT64 sessionKey);
};