#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2OuterServer.h"

unsigned int WINAPI JW2OuterServer::AcceptClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->AccpetClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::ConnectClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->ConnectClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::ReceiveClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->ReceiveClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::UpdateClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->UpdateClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::SendClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->SendClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::WorkClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->WorkClient();

	return 0;
}

unsigned int WINAPI JW2OuterServer::DisconnectClient(LPVOID selfInstanceAddress)
{
	JW2OuterServer* jw2OuterServerAddress;

	jw2OuterServerAddress = (JW2OuterServer*)selfInstanceAddress;
	jw2OuterServerAddress->DisconnectClient();

	return 0;
}