#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2OuterServer.h"

unsigned int JW2OuterServer::ReceivePacket(UINT64 sessionKey, SerialByteDoubleEndedQueue* receivedPacketSBDEQ_Address)
{
	return 0;
}

unsigned int JW2OuterServer::SendPacket(UINT64 sessionKey, SerialByteDoubleEndedQueue* sendingPacketSBDEQ_Address)
{
	return 0;
}

unsigned int JW2OuterServer::PostAccept(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2OuterServer::PostConnect(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2OuterServer::PostReceive(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2OuterServer::PostUpdate(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2OuterServer::PostSend(UINT64 sessionKey)
{
	return 0;
}

unsigned int JW2OuterServer::PostDisconnect(UINT64 sessionKey)
{
	return 0;
}