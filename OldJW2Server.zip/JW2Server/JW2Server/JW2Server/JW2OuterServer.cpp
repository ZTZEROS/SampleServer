#include "FirstOrderLibrary.h"
#include "SecondOrderLibrary.h"
#include "JW2.h"
#include "JW2OuterServer.h"

JW2OuterServer::JW2OuterServer() {}
JW2OuterServer::~JW2OuterServer() {}

bool JW2OuterServer::Initialize()
{
	WSADATA wsaDatum;
	WSAPROTOCOL_INFO wsaProtocolInformation;
	LINGER lingeringTime;
	BOOL addressReuseOn;
	BOOL keepAliveOn;
	BOOL nagleAlgorithmOff;
	INT socketReceiveBufferSize;
	INT socketSendBufferSize;
	u_long nonblocked;

	SYSTEM_INFO systemInformation;

	{
		{
			FILE* jsonFile;
			GenericDocument<UTF16LE<>> jsonDocument;
			WCHAR* jsonBuffer;
			UINT jsonFileSize;

			_wfopen_s(&jsonFile, L"JW2Server/JW2Server.ini", L"r, ccs=UTF-16LE");

			jsonFileSize = _filelength(_fileno(jsonFile));

			jsonBuffer = (WCHAR*)malloc(jsonFileSize);
			ZeroMemory(jsonBuffer, jsonFileSize);
			fread_s(jsonBuffer, jsonFileSize, jsonFileSize, 1, jsonFile);
			fclose(jsonFile);

			jsonDocument.Parse(jsonBuffer);

			{
				IP_Address = jsonDocument[L"JW2OuterServer"][L"IP_Address"].GetString();
				Port = jsonDocument[L"JW2OuterServer"][L"Port"].GetUint();
				MaximumClientCount = jsonDocument[L"JW2OuterServer"][L"MaximumClientCount"].GetUint();
				ReceiveThreadCount = jsonDocument[L"JW2OuterServer"][L"ReceiveThreadCount"].GetUint();
				SendThreadCount = jsonDocument[L"JW2OuterServer"][L"SendThreadCount"].GetUint();
				WorkThreadCount = jsonDocument[L"JW2OuterServer"][L"WorkThreadCount"].GetUint();
			}

			free(jsonBuffer);
		}

		{
			CSV.resize(MaximumClientCount);
			STV.resize(JW2_OUTER_SERVER_SUB_THREAD_COUNT);

			{
				SS.Socket = INVALID_SOCKET;

				ZeroMemory(&SS.Address, sizeof(SS.Address));

				SS.Key = 0;
				SS.Index = 0;
				SS.Connected = 0;
				SS.Sendable = 0;
				SS.ReceiveCount = 0;
				SS.SendCount = 0;

				ZeroMemory(&SS.OverlappedReceiving, sizeof(SS.OverlappedReceiving));
				ZeroMemory(&SS.OverlappedSending, sizeof(SS.OverlappedSending));

				SS.ReceiveBQ.Initialize();
				SS.SendBQ.Initialize();
				SS.ReceiveQ.Initialize();
				SS.SendQ.Initialize();

				InitializeSRWLock(&SS.Lock);
			}

			{
				FOR(i, CSV.size())
				{
					CSV[i].Socket = INVALID_SOCKET;

					ZeroMemory(&CSV[i].Address, sizeof(CSV[i].Address));

					CSV[i].Key = 0;
					CSV[i].Index = 0;
					CSV[i].Connected = 0;
					CSV[i].Receivable = 0;
					CSV[i].Sendable = 0;
					CSV[i].ReceiveCount = 0;
					CSV[i].SendCount = 0;

					ZeroMemory(&CSV[i].OverlappedReceiving, sizeof(CSV[i].OverlappedReceiving));
					ZeroMemory(&CSV[i].OverlappedSending, sizeof(CSV[i].OverlappedSending));

					CSV[i].ReceiveBQ.Initialize();
					CSV[i].SendBQ.Initialize();
					CSV[i].ReceiveQ.Initialize();
					CSV[i].SendQ.Initialize();

					CSV[i].CurrentPhase = JW2_CLIENT_PHASE_ACCEPT;

					InitializeSRWLock(&CSV[i].Lock);
				}
			}

			SUB_THREAD_ON = 1;

			CURRENT_ACCEPTION_COUNT = 0;



			ACP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);
			CCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);

			RCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);
			UCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);
			SCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);
			WCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);

			DCP = CreateIoCompletionPort(INVALID_HANDLE_VALUE, nullptr, NULL, 1);

			SelfInstanceAddress = this;
		}

		{
			PACKET_SBDEQ_TLP.Initialize();

			CURRENT_SBDEQ_COUNT = 0;
			ALLOCATED_SBDEQ_COUNT = 0;
			DEALLOCATED_SBDEQ_COUNT = 0;
		}
	}

	{
		CHECK_ERROR(WSAStartup(0x0202, &wsaDatum));

		SS.Socket = WSASocket(PF_INET, SOCK_STREAM, IPPROTO_TCP, nullptr, 0, WSA_FLAG_OVERLAPPED);
		CHECK_INVALID_SOCKET(SS.Socket);

		//{
		//	lingeringTime.l_onoff = 1;
		//	lingeringTime.l_linger = 0;
		//	CHECK_SOCKET_ERROR(setsockopt(SS.Socket, SOL_SOCKET, SO_LINGER, (char*)&lingeringTime, sizeof(lingeringTime)));
		//}

		//{
		//	addressReuseOn = 1;
		//	CHECK_SOCKET_ERROR(setsockopt(SS.Socket, SOL_SOCKET, SO_REUSEADDR, (char*)&addressReuseOn, sizeof(addressReuseOn)));
		//}

		{
			keepAliveOn = 1;
			CHECK_SOCKET_ERROR(setsockopt(SS.Socket, SOL_SOCKET, SO_KEEPALIVE, (char*)&keepAliveOn, sizeof(keepAliveOn)));
		}

		{
			nagleAlgorithmOff = 1;
			CHECK_SOCKET_ERROR(setsockopt(SS.Socket, IPPROTO_TCP, TCP_NODELAY, (char*)&nagleAlgorithmOff, sizeof(nagleAlgorithmOff)));
		}

		//{
		//	socketReceiveBufferSize = 0;
		//	CHECK_SOCKET_ERROR(setsockopt(SS.Socket, SOL_SOCKET, SO_RCVBUF, (char*)&socketReceiveBufferSize, sizeof(socketReceiveBufferSize)));
		//}

		//{
		//	socketSendBufferSize = 0;
		//	CHECK_SOCKET_ERROR(setsockopt(SS.Socket, SOL_SOCKET, SO_SNDBUF, (char*)&socketSendBufferSize, sizeof(socketSendBufferSize)));
		//}

		//{
		//	nonblocked = 1;
		//	CHECK_SOCKET_ERROR(ioctlsocket(SS.Socket, FIONBIO, &nonblocked));
		//}

		SS.Address.sin_family = AF_INET;
		SS.Address.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
		//InetPton(AF_INET, ipAddress, &SS.Address.sin_addr); //inet_addr(INADDR_ANY); //InetNtop();
		//WSAAddressToString();
		//WSAStringToAddress();
		SS.Address.sin_port = htons(Port);

		CHECK_SOCKET_ERROR(bind(SS.Socket, (SOCKADDR*)&SS.Address, sizeof(SS.Address)));
		CHECK_SOCKET_ERROR(listen(SS.Socket, SOMAXCONN));
	}

	{
		srand(time(nullptr));
		//srand(2705);

		GetSystemInfo(&systemInformation);
	}

	{
		STV[JW2_OUTER_SERVER_SUB_THREAD_ACCEPT].Handle = (HANDLE)_beginthreadex(nullptr, 0, AcceptClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_ACCEPT].IdentificationNumber);
		STV[JW2_OUTER_SERVER_SUB_THREAD_CONNECT].Handle = (HANDLE)_beginthreadex(nullptr, 0, ConnectClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_CONNECT].IdentificationNumber);

		STV[JW2_OUTER_SERVER_SUB_THREAD_RECEIVE].Handle = (HANDLE)_beginthreadex(nullptr, 0, ReceiveClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_RECEIVE].IdentificationNumber);
		STV[JW2_OUTER_SERVER_SUB_THREAD_UPDATE].Handle = (HANDLE)_beginthreadex(nullptr, 0, UpdateClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_UPDATE].IdentificationNumber);
		STV[JW2_OUTER_SERVER_SUB_THREAD_SEND].Handle = (HANDLE)_beginthreadex(nullptr, 0, SendClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_SEND].IdentificationNumber);
		
		STV[JW2_OUTER_SERVER_SUB_THREAD_WORK].Handle = (HANDLE)_beginthreadex(nullptr, 0, WorkClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_WORK].IdentificationNumber);
		
		STV[JW2_OUTER_SERVER_SUB_THREAD_DISCONNECT].Handle = (HANDLE)_beginthreadex(nullptr, 0, DisconnectClient, this, 0, &STV[JW2_OUTER_SERVER_SUB_THREAD_DISCONNECT].IdentificationNumber);
	}

	return 0;
}

bool JW2OuterServer::Update()
{


	return 0;
}

bool JW2OuterServer::Render()
{


	return 0;
}

bool JW2OuterServer::Terminalize()
{
	HANDLE_V subThreadHandleV;

	subThreadHandleV.resize(STV.size());

	FOR(i, subThreadHandleV.size())
	{
		subThreadHandleV[i] = STV[i].Handle;
	}

	{
		{
			closesocket(SS.Socket); //close accept thread

			FOR(i, CSV.size()) //induct client disconnection
			{
				shutdown(CSV[i].Socket, SD_BOTH);
			}

			FOR(i, CSV.size()) //confirm disconnection
			{
				if (CSV[i].CurrentPhase != JW2_CLIENT_PHASE_ACCEPT)
				{
					--i;

					Sleep(0);
				}
			}

			SUB_THREAD_ON = 0;

			PostQueuedCompletionStatus(ACP, NULL, NULL, nullptr);
			PostQueuedCompletionStatus(CCP, NULL, NULL, nullptr);
			
			PostQueuedCompletionStatus(RCP, NULL, NULL, nullptr);
			PostQueuedCompletionStatus(UCP, NULL, NULL, nullptr);
			PostQueuedCompletionStatus(SCP, NULL, NULL, nullptr);
			
			PostQueuedCompletionStatus(WCP, NULL, NULL, nullptr);

			PostQueuedCompletionStatus(DCP, NULL, NULL, nullptr);
		}

		{
			WaitForMultipleObjects(subThreadHandleV.size(), &subThreadHandleV[0], 1, INFINITE);

			CloseHandle(ACP);
			CloseHandle(CCP);

			CloseHandle(RCP);
			CloseHandle(UCP);
			CloseHandle(SCP);

			CloseHandle(WCP);

			CloseHandle(DCP);

			FOR(i, STV.size())
			{
				CloseHandle(STV[i].Handle);
			}

			CSV.clear();
			STV.clear();
		}
	}

	{

	}

	{
		WSACleanup();
	}

	{
		printf("JW2OuterServer is Terminated." CRALF
			);
	}

	return 0;
}