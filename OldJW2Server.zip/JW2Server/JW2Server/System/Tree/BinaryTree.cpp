#include "FirstOrderLibrary.h"
#include "BinaryTree.h"


BinaryTree::BinaryTree()
{
}


BinaryTree::~BinaryTree()
{
}
