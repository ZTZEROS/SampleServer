#pragma once
class BinaryTree
{
public:
	BinaryTree();
	~BinaryTree();
};

