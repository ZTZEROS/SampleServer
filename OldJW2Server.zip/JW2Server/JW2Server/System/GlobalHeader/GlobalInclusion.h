#pragma once

#include "GlobalTypeDefinition.h"
#include "GlobalDefinition.h"
#include "GlobalEnumeration.h"
#include "GlobalUnion.h"
#include "GlobalStructure.h"
//#include "GlobalClass.h"
//#include "GlobalVariable.h"
//#include "GlobalConstant.h"

using namespace std;
//using namespace GlobalConstant;
//using namespace GlobalVariable;