#include "FirstOrderLibrary.h"
#include "MemoryDumper.h"

MemoryDumper MEMORY_DUMPER;

long MemoryDumper::DumpCount;
