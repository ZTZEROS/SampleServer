#include "FirstOrderLibrary.h"
#include "Exception.h"

Exception::Exception() {}
Exception::~Exception() {}