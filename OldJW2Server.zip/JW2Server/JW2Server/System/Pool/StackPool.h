#pragma once

struct StackPoolTop
{
	volatile unsigned int Index;
	volatile unsigned int WorkCount;
};

template<typename DatumType>
class StackPool
{
private:
	StackPoolTop Top;
	//volatile unsigned int TopIndex;
	//volatile unsigned int WorkCount;
	volatile unsigned int CurrentCount;
	unsigned int MaximumCount;

	DatumType* DatumAddressA[POOL_SIZE];

	DatumType DatumA[POOL_SIZE];

public:
	StackPool() {}
	~StackPool() {}

	bool Initialize()
	{
		Top.Index = 0xffffffff;
		Top.WorkCount = 0;
		CurrentCount = 0;
		MaximumCount = sizeof(DatumA) / sizeof(DatumType);

		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			DatumAddressA[i] = DatumA[i];
		}

		memset(DatumA, 0, sizeof(DatumA));

		return 0;
	}

	bool Terminalize()
	{
		Top.Index = 0xffffffff;
		Top.WorkCount = 0;
		CurrentCount = 0;

		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			DatumAddressA[i] = DatumA[i];
		}

		return 0;
	}

	DatumType* Allocate()
	{
		__declspec(align(16)) StackPoolTop oldTop;
		StackPoolTop newTop;
		unsigned int maximumCount;
		DatumType* datumAddress;

		maximumCount = MaximumCount;

		do
		{
			oldTop.WorkCount = Top.WorkCount;
			oldTop.Index = Top.Index;

			newTop.WorkCount = oldTop.WorkCount;
			newTop.Index = oldTop.Index;

			--newTop.Index;

			if (newTop.Index < maximumCount)
			{
				datumAddress = DatumAddressA[localTop.TopIndex];
			}
			else
			{
				datumAddress = nullptr;

				break;
			}
		}
		while (InterlockedCompareExchange64(&Top, newTop, oldTop) != oldTop);

		return datumAddress;
	}

	DatumType* Deallocate(DautmType* datumAddress)
	{
		__declspec(align(16)) StackPoolTop oldTop;
		StackPoolTop newTop;
		unsigned int maximumCount;

		maximumCount = MaximumCount;

		do
		{
			do
			{
				oldTop.WorkCount = Top.WorkCount;
				oldTop.Index = Top.Index;

				newTop.WorkCount = oldTop.WorkCount;
				newTop.Index = oldTop.Index;

				++newTop.Index;

				if (newTop.Index < maximumCount)
				{

				}
				else
				{
					break;
				}
			}
			while (InterlockedCompareExchange64(&Top, newTop, oldTop) != oldTop);
		}
		while(InterlockedCompareExchangePointer(&DatumAddressA[localTop.TopIndex], datumAddress, nullptr) != datumAddress);

		return nullptr;
	}
};