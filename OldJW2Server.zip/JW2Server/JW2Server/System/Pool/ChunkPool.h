#pragma once

template<typename DatumType>
struct Piece
{
	DatumType Datum;
};

template<typename DatumType>
struct Chunk
{
	volatile unsigned int TopIndex;
	volatile unsigned int ReferenceCount;
	volatile unsigned int CurrentCount;
	unsigned int MaximumCount;

	Piece<DatumType> PieceA[POOL_UNIT_SIZE];
};

template<typename DatumType>
class ChunkPool
{
private:
	volatile unsigned int AllocatingIndex; //TopIndex
	volatile unsigned int DeallocatingIndex; //BottomIndex
	volatile unsigned int CurrentCount; //CurrentChunkCount
	unsigned int MaximumCount; //MaximumChunkCount

	volatile unsigned int TopIndexA[POOL_UNIT_COUNT];
	volatile unsigned int ReferenceCountA[POOL_UNIT_COUNT];
	volatile unsigned int CurrentCountA[POOL_UNIT_COUNT]; //CurrentPieceCountA
	unsigned int MaximumCountA[POOL_UNIT_COUNT]; //MaximumPieceCountA

	Chunk<DatumType*> DatumAddressChunkA[POOL_UNIT_COUNT];

	DatumType* DatumAddressA[POOL_UNIT_COUNT][POOL_UNIT_SIZE];
	DatumType DatumA[POOL_UNIT_COUNT][POOL_UNIT_SIZE]; //Pool

private:
	volatile unsigned int FrontIndex;
	volatile unsigned int CurrentIndex;
	volatile unsigned int NextIndex;
	unsigned int MaximumCount;

	volatile unsigned int ReferenceCount[POOL_SIZE];
	DatumType DatumA[POOL_SIZE];

	Chunk<DatumType> DatumChunkA[POOL_UNIT_COUNT];

public:
	Pool() {}
	~Pool() {}

	bool Initialize()
	{
		AllocatingIndex = 0xffffffff;
		DeallocatingIndex = 0xffffffff;
		CurrentCount = 0;
		MaximumCount = sizeof(DatumA) / sizeof(DatumA[0]);

		//memset(TopIndexA, 0, sizeof(TopIndexA));
		//memset(ReferenceCountA, 0, sizeof(ReferenceCountA));
		//memset(CurrentCountA, 0, sizeof(CurrentCountA));
		//memset(MaximumCountA, 0, sizeof(MaximumCountA));
		FOR(i, MaximumCount)
		{
			TopIndexA[i] = 0xffffffff;
			ReferenceCount[i] = 0;
			CurrentCountA[i] = 0;
			MaximumCountA[i] = sizeof(DatumA[0][0]) / sizeof(DatumType);
		}

		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			FOR(j, MaximumCountA[i])
			{
				DatumAddressA[i][j] = &DatumA[i][j];
			}
		}

		memset(DatumA, 0, sizeof(DatumA));

		return 0;
	}

	bool Terminalize()
	{
		LastIndex = 0xffffffff;

		FOR(i, MaximumCount)
		{
			PieceA[i].Allocated = 0;
		}

		return 0;
	}

	DatumType* Allocate()
	{
		unsigned int currentIndex;
		DatumType* dautumAddress;

		while (1)
		{
			currentIndex = InterlockedIncrement(&LastIndex);

			if (!InterlockedExchange(&PieceA[currentIndex].Allocated, 1))
			{
				dautumAddress = &PieceA[currentIndex].Datum;

				break;
			}
		}

		return datumAddress;
	}

	DatumType* Deallocate(DatumType* datumAddress)
	{
		if (InterlockedExchange(&(Piece<DatumType>*)datumAddress)->Allocated, 0)
		{
			return nullptr;
		}
		else return datumAddress;

		return 0;
	}
};

