#pragma once

template<typename DatumType>
struct ThreadLocalChunk;

template<typename DatumType>
class ThreadLocalPool;

template <typename DatumType>
struct ThreadLocalPiece
{
	//unsigned int Index; //PieceIndex
	//unsigned int ReferenceCount;

	ThreadLocalChunk<DatumType>* TLC_Address;

	DatumType Datum;
};

template<typename DatumType>
struct ThreadLocalChunk
{
	unsigned int CurrentIndex;
	unsigned int CurrentAllocationCount;
	unsigned int CurrentDeallocationCount;
	unsigned int MaximumCount;

	ThreadLocalPool<DatumType>* TLP_Address;
	
	ThreadLocalPiece<DatumType> PieceA[THREAD_LOCAL_PIECE_COUNT]; //TLPA //ThreadLocalPieceA
};

template<typename DatumType>
class ThreadLocalPool
{
private:
	volatile unsigned int CurrentIndex;
	volatile unsigned int CurrentCount;
	unsigned int MaximumCount;

	volatile unsigned int AllocatedA[THREAD_LOCAL_CHUNK_COUNT];

	ThreadLocalChunk<DatumType> ChunkA[THREAD_LOCAL_CHUNK_COUNT]; //TLCA //ThreadLocalChunkA //Pool //ThreadLocalPool
	
	unsigned int DeallocationCountA[THREAD_LOCAL_CHUNK_COUNT];
	DatumType DatumA[THREAD_LOCAL_CHUNK_COUNT][THREAD_LOCAL_PIECE_COUNT];

	DWORD TLS_Index; //ThreadLocalStorageIndex;
	//__declspec(thread) ThreadLocalChunk<DatumType>* ChunkAddress;

public:
	ThreadLocalPool() {}
	~ThreadLocalPool() {}

	bool Initialize()
	{
		CurrentIndex = 0xffffffff;
		CurrentCount = sizeof(ChunkA) / sizeof(ThreadLocalChunk<DatumType>);
		//CurrentCount = 0;
		MaximumCount = sizeof(ChunkA) / sizeof(ThreadLocalChunk<DatumType>);

		//ZeroMemory(ChunkA, sizeof(ChunkA));
		FOR(i, MaximumCount)
		{
			AllocatedA[i] = 0;

			ChunkA[i].TLP_Address = this;

			ChunkA[i].CurrentIndex = 0xffffffff;
			ChunkA[i].CurrentAllocationCount = 0;
			ChunkA[i].CurrentDeallocationCount = 0;
			ChunkA[i].MaximumCount = sizeof(ChunkA[i].PieceA) / sizeof(ThreadLocalPiece<DatumType>);

			//ZeroMemory(ChunkA[i].PieceA[j], sizeof(ChunkA[i].PieceA[j]));
			FOR(j, ChunkA[i].MaximumCount)
			{
				ChunkA[i].PieceA[j].TLC_Address = &ChunkA[i];
				
				ZeroMemory(&ChunkA[i].PieceA[j].Datum, sizeof(ChunkA[i].PieceA[j].Datum));
				
				//ChunkA[i].PieceA[j].Index = j;
				//ChunkA[i].PieceA[j].RefernceCount = 0;
			}
		}

		FOR(i, MaximumCount)
		{
			DeallocationCountA[i] = 0;
		}
		
		ZeroMemory(DatumA, sizeof(DatumA));

		TLS_Index = TlsAlloc();

		if (TLS_Index == TLS_OUT_OF_INDEXES) MEMORY_DUMPER.SelfCrash();

		return 0;
	}

	bool Terminalize()
	{
		CurrentIndex = 0xffffffff;
		CurrentCount = MaximumCount;
		//CurrentCount = 0;
		
		//ZeroMemory(ChunkA, sizeof(ChunkA));
		FOR(i, MaximumCount)
		{
			AllocatedA[i] = 0;

			ChunkA[i].CurrentIndex = 0xffffffff;
			ChunkA[i].CurrentAllocationCount = 0;
			ChunkA[i].CurrentDeallocationCount = 0;

			//ZeroMemory(ChunkA[i].PieceA, sizeof(ChunkA[i].PieceA));
			FOR(j, ChunkA[i].MaximumCount)
			{
				ZeroMemory(&ChunkA[i].PieceA[j].Datum, sizeof(ChunkA[i].PieceA[j].Datum));
				
				//ChunkA[i].PieceA[j].RefernceCount = 0;
			}
		}

		FOR(i, MaximumCount)
		{
			DeallocationCountA[i] = 0;
		}

		ZeroMemory(DatumA, sizeof(DatumA));

		TlsFree(TLS_Index);
		
		return 0;
	}

	DatumType* Allocate()
	{
		ThreadLocalChunk<DatumType>* chunkAddress; //tlcAddress //threadLocalChunkAddress
		DatumType* datumAddress;

		unsigned int currentIndex;
		unsigned int maximumCount;

		maximumCount = MaximumCount;

		while (1)
		{
			chunkAddress = (ThreadLocalChunk<DatumType>*)TlsGetValue(TLS_Index);

			if (chunkAddress)
			{
				currentIndex = ++chunkAddress->CurrentIndex;

				if (currentIndex < chunkAddress->MaximumCount)
				{
					++chunkAddress->CurrentAllocationCount;

					datumAddress = &chunkAddress->PieceA[currentIndex].Datum;

					return datumAddress;
				}
			}

			while (CurrentCount)
			{
				currentIndex = InterlockedIncrement(&CurrentIndex);

				currentIndex &= maximumCount - 1;

				chunkAddress = &ChunkA[currentIndex];

				if (!InterlockedExchange(&AllocatedA[currentIndex], 1))
				{
					InterlockedDecrement(&CurrentCount);

					break;
				}
			}

			TlsSetValue(TLS_Index, chunkAddress);
		}

		return nullptr;
	}

	DatumType* Deallocate(DatumType* datumAddress)
	{
		ThreadLocalChunk<DatumType>* chunkAddress;

		unsigned int currentIndex;

		chunkAddress = ((ThreadLocalPiece<DatumType>*)((char*)datumAddress - sizeof(ThreadLocalPiece<DatumType>*)))->TLC_Address;

		currentIndex = (chunkAddress - &ChunkA[0]) / sizeof(ThreadLocalChunk<DatumType*>);

		++chunkAddress->CurrentDeallocationCount;

		if (chunkAddress->CurrentDeallocationCount == chunkAddress->MaximumCount)
		{
			chunkAddress->CurrentIndex = 0;

			InterlockedExchange(&AllocatedA[currentIndex], 0);
			InterlockedIncrement(&CurrentCount);
		}

		//++ChunkA[currentIndex].CurrentDeallocationCount;
		//
		//if (ChunkA[currentIndex].CurrentDeallocationCount == ChunkA[currentIndex].MaximumCount)
		//{
		//	ChunkA[currentIndex].CurrentIndex = 0;
		//
		//	InterlockedExchange(&AllocatedA[currentIndex], 0);
		//	InterlockedIncrement(&CurrentCount);
		//}

		return nullptr;
	}
};