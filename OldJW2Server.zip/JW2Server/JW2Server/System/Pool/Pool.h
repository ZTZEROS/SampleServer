#pragma once

template<typename DatumType>
class Pool
{
private:
	volatile unsigned int AllocatingIndex; //CurrentAllocatingIndex; //FrontIndex //TopIndex
	volatile unsigned int DeallocatingIndex; //CurrentDeallocatingIndex //FrontIndex //TopIndex
	volatile unsigned int CurrentCount;
	//volatile unsigned int NextIndex; //BottomIndex
	unsigned int MaximumCount;

	//SRWLOCK Lock[POOL_SIZE];
	volatile unsigned int AllocatableA[POOL_SIZE];
	volatile unsigned int AllocatedA[POOL_SIZE];

	DatumType* DatumAddressA[POOL_SIZE]; //PoolDatumAddress
	
	DatumType DatumA[POOL_SIZE]; //PoolDatum //Pool

public:
	Pool() {}
	~Pool() {}

	bool Initialize()
	{
		AllocatingIndex = 0xffffffff;
		DeallocatingIndex = 0xffffffff;
		CurrentCount = sizeof(DatumA) / sizeof(DatumType);
		//CurrentCount = 0;
		MaximumCount = sizeof(DatumA) / sizeof(DatumType);

		FOR(i, MaximumCount)
		{
			AllocatableA[i] = 1;
			AllocatedA[i] = 0;

			DatumAddressA[i] = &DatumA[i];
		}

		memset(DatumA, 0, sizeof(DatumA));

		//CurrentCount = MaximumCount;

		return 0;
	}

	bool Terminalize()
	{
		AllocatingIndex = 0xffffffff;
		DeallocatingIndex = 0xffffffff;
		CurrentCount = MaximumCount;

		FOR(i, MaximumCount)
		{
			AllocatableA[i] = 1;
			AllocatedA[i] = 0;
		}
		
		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			DatumAddressA[i] = &DatumA[i];
		}

		return 0;
	}

	DatumType* Allocate()
	{
		unsigned int currentIndex;
		unsigned int maximumCount;
		DatumType* datumAddress;

		maximumCount = MaximumCount;

		while (CurrentCount)
		{
			currentIndex = InterlockedIncrement(&AllocatingIndex);

			currentIndex &= maximumCount - 1;
			//if (currentIndex < maximumCount);
			//else
			//{
			//	currentIndex -= maximumCount;
			//
			//	AllocationIndex = currentIndex;
			//	//InterlockedExchange(&AllocationIndex, currentIndex);
			//	//InterlockedExchange(&AllocationIndex, 0xffffffff);
			//
			//	//continue;
			//}

			//datumAddress = DatumAddressA[currentIndex];

			if (InterlockedExchange(&AllocatableA[currentIndex], 0))
			{
				datumAddress = DatumAddressA[currentIndex];
				//DatumAddressA[currentIndex] = nullptr;
				//datumAddress = &DatumA[currentIndex];

				InterlockedDecrement(&CurrentCount);
				InterlockedExchange(&AllocatedA[currentIndex], 1);

				return datumAddress;
			}
		}

		return nullptr;
	}

	DatumType* Deallocate(DatumType* datumAddress)
	{
		unsigned int currentIndex;
		unsigned int maximumCount;

		maximumCount = MaximumCount;

		while (CurrentCount < maximumCount)
		{
			currentIndex = InterlockedIncrement(&DeallocatingIndex);

			currentIndex &= maximumCount - 1;
			//if (currentIndex < maximumCount);
			//else
			//{
			//	currentIndex -= maximumCount;
			//
			//	DeallocationIndex = currentIndex;
			//	//InterlockedExchange(&DeallocationIndex, currentIndex);
			//	//InterlockedExchange(&DeallocationIndex, 0xffffffff);
			//
			//	//continue;
			//}

			//currentIndex = (datumAddress - &DatumA[0]) / sizeof(DatumType);

			if(InterlockedExchange(&AllocatedA[currentIndex], 0))
			{
				DatumAddressA[currentIndex] = datumAddress;
				//DatumA[currentIndex];

				InterlockedIncrement(&CurrentCount);
				InterlockedExchange(&AllocatableA[currentIndex], 1);

				return datumAddress;
			}
		}

		return nullptr;
	}

	unsigned int GetAllocatingIndex() { return AllocatingIndex; }
	unsigned int GetDeallocatingIndex() { return DeallocatingIndex; }
	unsigned int GetCurrentCount() { return CurrentCount; }
	unsigned int GetCurrentSize() { return CurrentCount * sizeof(DatumType); }
	unsigned int GetMaximumCount() { return MaximumCount; }
	unsigned int GetMaximumSize() { return MaximumCount * sizeof(DatumType); }
};