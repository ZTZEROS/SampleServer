#pragma once

#pragma once

template<typename DatumType>
class PiecePool
{
private:
	volatile unsigned int AllocationIndex; //TopIndex
	volatile unsigned int DeallocationIndex; //BottomIndex
	volatile unsigned int CurrentCount;
	unsigned int MaximumCount;

	//volatile unsigned int ReferenceCountA[POOL_SIZE];

	DatumType* DatumAddressA[POOL_SIZE];

	DatumType DatumA[POOL_SIZE]; //Pool

public:
	PiecePool() {}
	~PiecePool() {}

	bool Initialize()
	{
		AllocationIndex = 0xffffffff;
		DeallocationIndex = 0xffffffff;
		CurrentCount = 0;
		MaximumCount = sizeof(DatumA) / sizeof(DatumType);

		//memset(ReferenceCountA, 0, sizeof(ReferenceCountA));

		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			DatumAddressA[i] = &DatumA[i];
		}

		memset(DatumA, 0, sizeof(DatumA));

		return 0;
	}

	bool Terminalize()
	{
		AllocationIndex = 0xffffffff;
		DeallocationIndex = 0xffffffff;
		CurrentCount = 0;

		//memset(ReferenceCountA, 0, sizeof(ReferenceCountA));

		//memset(DatumAddressA, 0, sizeof(DatumAddressA));
		FOR(i, MaximumCount)
		{
			DatumAddressA[i] = &DatumA[i];
		}

		return 0;
	}

	DatumType* Allocate()
	{
		unsigned int currentIndex;
		unsigned int maximumCount;
		DatumType* datumAddress;

		maximumCount = MaximumCount;

		while (CurrentCount < maximumCount)
		{
			currentIndex = InterlockedIncrement(&AllocationIndex);

			//currentIndex &= maximumCount - 1;
			if (currentIndex < maximumCount);
			else
			{
				currentIndex -= maximumCount;

				AllocationIndex = currentIndex;
				//InterlockedExchange(&AllocationIndex, currentIndex);
				//InterlockedExchange(&AllocationIndex, 0xffffffff);

				//continue;
			}

			datumAddress = DatumAddressA[currentIndex];

			//if (!InterlockedExchange(&ReferenceCountA[currentIndex], 1))
			{
				if (InterlockedCompareExchangePointer(&DatumAddressA[currentIndex], nullptr, datumAddress) == datumAddress)
				{
					InterlockedDecrement(&CurrentCount);
				
					return datumAddress;
				}
			}

			//if (InterlockedExchange(&AllocatableA[currentIndex], 0))
			//{
			//	InterlockedDecrement(&CurrentCount);
			//	InterlockedExchange(&AllocatedA[currentIndex], 1);
			//
			//	return datumAddress;
			//}
		}

		return nullptr;
	}

	DatumType* Deallocate(DatumType* datumAddress)
	{
		unsigned int currentIndex;
		unsigned int maximumCount;

		maximumCount = MaximumCount;

		while (CurrentCount < maximumCount)
		{
			currentIndex = InterlockedIncrement(&DeallocationIndex);

			//currentIndex &= maximumCount - 1;
			if (currentIndex < maximumCount);
			else
			{
				currentIndex -= maximumCount;
				
				DeallocationIndex = currentIndex;
				//InterlockedExchange(&DeallocationIndex, currentIndex);
				//InterlockedExchange(&DeallocationIndex, 0xffffffff);

				//continue;
			}

			//if (ReferenceCountA[currentIndex])
			{
				if (InterlockedCompareExchangePointer(&DatumAddressA[currentIndex], datumAddress, nullptr) == nullptr)
				{
					InterlockedIncrement(&CurrentCount);
					//InterlockedExchange(&ReferenceCountA[currentIndex], 0);
			
					return datumAddress;
				}
			}

			//if (InterlockedExchange(&AllocatedA[currentIndex], 0))
			//{
			//	DatumAddressA[currentIndex] = datumAddress;
			//
			//	InterlockedIncrement(&CurrentCount);
			//	InterlockedExchange(&AllocatableA[currentIndex], 1);
			//
			//	return datumAddress;
			//}
		}

		return nullptr;
	}
};