#pragma once

class EthernetProfiler
{
private:

public:
	EthernetProfiler();
	virtual ~EthernetProfiler();
};
