#pragma once

#pragma comment(linker, "/subsystem:windows")

#include "JW2Server/JW2Server.h"