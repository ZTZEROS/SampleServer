#include "FirstOrderLibrary.h"
#include "Console.h"

int main(int argumentCount, char* argumentVector[])
{
	ExecuteJW2Server(argumentCount, argumentVector);

	system("pause");

	return 0;
}