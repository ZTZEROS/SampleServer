#pragma once

#pragma comment(linker, "/subsystem:console")

#include "JW2Server/JW2Server.h"