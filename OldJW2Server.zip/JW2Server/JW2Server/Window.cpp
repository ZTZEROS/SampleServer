#include "FirstOrderLibrary.h"
#include "Window.h"

int APIENTRY WinMain(_In_ HINSTANCE instanceHandle, _In_opt_ HINSTANCE previousInstanceHandle, _In_ LPSTR lpCommandLine, _In_ int nCommandShow)
{
	ExecuteJW2Server(instanceHandle, previousInstanceHandle, lpCommandLine, nCommandShow);

	return 0;
}