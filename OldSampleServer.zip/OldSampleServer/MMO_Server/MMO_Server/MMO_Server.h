#pragma once

#include "MMO_Server\MMO.h"
#include "MMO_Server\MMO_BaseClient.h"
#include "MMO_Server\MMO_DerivedClient.h"
#include "MMO_Server\MMO_InnerClient.h"
#include "MMO_Server\MMO_BaseServer.h"
#include "MMO_Server\MMO_DerivedServer.h"