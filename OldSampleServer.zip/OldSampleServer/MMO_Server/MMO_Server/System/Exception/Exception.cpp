#include "pch.h"
#include "Exception.h"

Exception::Exception() {}
Exception::~Exception() {}