#include "pch.h"
#include "BresenhamLine.h"


BresenhamLine::BresenhamLine()
{
}


BresenhamLine::~BresenhamLine()
{
}
