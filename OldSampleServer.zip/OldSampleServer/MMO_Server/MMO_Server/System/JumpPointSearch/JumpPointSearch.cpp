#include "pch.h"
#include "JumpPointSearch.h"


JumpPointSearch::JumpPointSearch()
{
}


JumpPointSearch::~JumpPointSearch()
{
}
