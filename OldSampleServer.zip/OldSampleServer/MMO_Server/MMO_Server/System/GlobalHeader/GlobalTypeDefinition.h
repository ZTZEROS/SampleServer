#pragma once

typedef unsigned char BYTE1;
typedef unsigned short BYTE2;
typedef unsigned long BYTE4;
typedef unsigned long long BYTE8;

//typedef BYTE1 BYTE;
//typedef BYTE2 WORD;
//typedef BYTE4 DWORD;
//typedef BYTE8 QWORD;

//typedef BYTE1 BOOL; //typedef bool BOOL;

//typedef short int INT16;
//typedef long int INT32;
//typedef long long int INT64;

//typedef unsigned short int UINT16;
//typedef unsigned long int UINT32;
//typedef unsigned long long int UINT64;