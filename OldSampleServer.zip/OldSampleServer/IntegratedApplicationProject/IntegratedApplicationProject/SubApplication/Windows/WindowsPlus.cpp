#include "stdafx.h"
#include "Windows.h"

/*
BOOL InitializeMain()
{
	return 0;
}

BOOL UpdateMain()
{
	return 0;
}

BOOL RenderMain()
{
	return 0;
}

BOOL TerminalizeMain()
{
	return 0;
}

INT AcceptSub()
{
	return 0;
}

INT ConnectSub()
{
	return 0;
}

INT DisconnectMain()
{
	return 0;
}

INT DisconnectSub()
{
	return 0;
}

INT ReceiveMainPacket()
{
	return 0;
}

INT ReceiveSubPacket()
{
	return 0;
}

INT SendMainPacket()
{
	return 0;
}

INT SendSubPacket()
{
	return 0;
}

INT ProcessReceivedMainPacket()
{
	return 0;
}

INT ProcessReceivedSubPacket()
{
	return 0;
}

INT ProcessSendingMainPacket()
{
	return 0;
}

INT ProcessSendingSubPacket()
{
	return 0;
}

BOOL CheckReceivedMainPacket()
{
	return 0;
}

BOOL CheckReceivedSubPacket()
{
	return 0;
}

BOOL CheckSendingMainPacket()
{
return 0;
}

BOOL CheckSendingSubPacket()
{
return 0;
}
*/