#include "stdafx.h"
#include "Protocol.h"
#include "ChatClient.h"

BOOL InitializeChatClient()
{
	return 0;
}

BOOL UpdateChatClient()
{
	return 0;
}

BOOL RenderChatClient()
{
	return 0;
}

BOOL TerminalizeChatClient()
{
	return 0;
}

INT ConnectChatClient()
{
	return 0;
}

INT DisconnectChatServer()
{
	return 0;
}

INT ReceiveChatServerPacket()
{
	return 0;
}

INT SendChatClientPacket()
{
	return 0;
}

INT ProcessReceivedChatServerPacket()
{
	return 0;
}

INT ProcessSendingChatClientPacket()
{
	return 0;
}

BOOL CheckReceivedChatClientPacket()
{
	return 0;
}

BOOL CheckSendingChatServerPacket()
{
	return 0;
}