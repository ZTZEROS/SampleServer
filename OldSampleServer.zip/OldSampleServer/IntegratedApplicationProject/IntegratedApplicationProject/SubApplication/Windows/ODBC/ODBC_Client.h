#pragma once

int APIENTRY ExecuteODBC_Client(HINSTANCE instanceHandle, HINSTANCE previousInstanceHandle, LPSTR lpCommandLine, int nCommandShow);