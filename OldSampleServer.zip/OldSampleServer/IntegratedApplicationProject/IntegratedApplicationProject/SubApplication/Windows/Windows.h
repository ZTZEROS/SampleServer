#pragma once

//#include "Chat\ChatClient.h"
//#include "ODBC\ODBC_Client.h"

/*
#include "resource.h"

#define MAX_LOADSTRING 128
#define WM_NETWORK (WM_USER + 1)



extern HINSTANCE MAIN_INSTANCE_HANDLE;
extern HWND MAIN_WINDOW_HANDLE;
extern HDC MAIN_WINDOW_DC_HANDLE;

extern WCHAR MAIN_WINDOW_TITLE[MAX_LOADSTRING];
extern WCHAR MAIN_WINDOW_CLASS_NAME[MAX_LOADSTRING];



LRESULT CALLBACK MainWindowProcedure(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK About(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK MainNetworkProcedure(HWND, UINT, WPARAM, LPARAM);

BOOL InitializeMain();
BOOL UpdateMain();
BOOL RenderMain();
BOOL TerminalizeMain();

INT AcceptSub();
INT ConnectSub();
INT ConnectToMain();
INT DisconnectMain();
INT DisconnectFromMain();
INT DisconnectSub();

INT ReceiveMainPacket();
INT ReceiveSubPacket();
INT SendMainPacket();
INT SendSubPacket();

INT ProcessReceivedMainPacket();
INT ProcessReceivedSubPacket();

INT ProcessSendingMainPacket();
INT ProcessSendingSubPacket();

BOOL CheckReceivedMainPacket();
BOOL CheckReceivedSubPacket();
BOOL CheckSendingMainPacket();
BOOL CheckSendingSubPacket();
*/