#pragma once

//#include "Chat\ChatServer.h"
//#include "FriendManagement\FriendManagementServer.h"
//#include "FriendManagement\FriendManagementClient.h"
//#include "Fighter\FighterServer.h"
//#include "Fighter\FighterClient.h"
//#include "IOCP_Chat\IOCP_ChatServer.h"
//#include "IOCP_Chat\IOCP_ChatClient.h"
//#include "HTTP\HTTP_Client.h"
//#include "ODBC\ODBC_Client.h"
//#include "Lan\LanServer.h"
//#include "Lan\LanClient.h"
//#include "AdvancedLAN\AdvancedLAN_Server.h"
//#include "AdvancedWAN\AdvancedWAN_Server.h"
//#include "LockFreeMemoryPool\LockFreeMemoryPool.h"
//#include "ThreadLocalMemoryPool\ThreadLocalMemoryPool.h"

//#include "AdvancedLogin\AdvancedLoginServer.h"
//#include "AdvancedChat\AdvancedChatServer.h"

#include "Monitor\MonitorServer.h"
//#include "PerformanceDataHelper\PerformanceDataHelper.h"

//#include "Experiment\MemoryCopyExperiment.h"
//#include "Experiment\QueueExperiment.h"
//#include "Experiment\IOCP_Experiment.h"
//#include "Experiment\ClassExperiment.h"

//#include "Experiment\JurassicWarServer.h"

//#include "MySQL\MySQL_Example.h"
//#include "MySQL\MySQL_Client.h"

#pragma comment(linker, "/subsystem:console")