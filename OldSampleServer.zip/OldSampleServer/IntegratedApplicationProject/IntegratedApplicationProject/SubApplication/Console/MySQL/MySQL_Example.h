#pragma once
#include "MySQL.h"

int ExecuteMySQL_Example(int argumentCount, char* argumentVector[]);