#pragma once

extern int ExecutePerformanceDataHelper(int argumentCount, char* argumentVector[]);