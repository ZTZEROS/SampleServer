#include "stdafx.h"
#include "AnotherLAN_Server.h"
