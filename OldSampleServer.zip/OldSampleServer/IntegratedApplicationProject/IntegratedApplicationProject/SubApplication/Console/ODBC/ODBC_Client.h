#pragma once

int ExecuteODBC_Client(int argumentCount, char* argumentVector[]);
