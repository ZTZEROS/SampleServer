#pragma once

int MemoryCopyExperiment(int argumentCount, char* argumentVector[]);
