#pragma once
class BaseLanClient
{
public:
	BaseLanClient();
	virtual ~BaseLanClient();
};

