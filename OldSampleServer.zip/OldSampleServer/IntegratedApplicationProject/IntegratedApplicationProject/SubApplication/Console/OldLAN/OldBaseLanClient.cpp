#include "stdafx.h"
#include "Lan.h"
#include "BaseLanClient.h"


BaseLanClient::BaseLanClient()
{
}


BaseLanClient::~BaseLanClient()
{
}
