#pragma once

class DerivedLanClient : public BaseLanClient
{
public:
	DerivedLanClient();
	virtual ~DerivedLanClient();
};

