#include "stdafx.h"
#include "Lan.h"
#include "BaseLanClient.h"
#include "DerivedLanClient.h"


DerivedLanClient::DerivedLanClient()
{
}


DerivedLanClient::~DerivedLanClient()
{
}
