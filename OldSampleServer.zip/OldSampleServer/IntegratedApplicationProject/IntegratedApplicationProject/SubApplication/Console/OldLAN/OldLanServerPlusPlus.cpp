#include "stdafx.h"
#include "LanServer.h"
