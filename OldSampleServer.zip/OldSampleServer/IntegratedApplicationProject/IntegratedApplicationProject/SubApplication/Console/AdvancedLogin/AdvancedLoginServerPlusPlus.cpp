#include "stdafx.h"
#include "AdvancedLoginServer.h"