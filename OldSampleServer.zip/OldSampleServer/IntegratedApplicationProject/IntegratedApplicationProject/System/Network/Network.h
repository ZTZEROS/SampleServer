#pragma once

enum NETWORK_LOCAL_CONSTANT
{

};