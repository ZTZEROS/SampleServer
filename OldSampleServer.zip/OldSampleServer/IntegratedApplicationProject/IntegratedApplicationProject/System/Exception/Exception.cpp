#include "stdafx.h"
#include "Exception.h"

Exception::Exception() {}
Exception::~Exception() {}