#include "stdafx.h"
#include "JumpPointSearch.h"


JumpPointSearch::JumpPointSearch()
{
}


JumpPointSearch::~JumpPointSearch()
{
}
