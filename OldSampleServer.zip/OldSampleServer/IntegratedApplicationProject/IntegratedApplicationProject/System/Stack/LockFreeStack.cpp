#include "stdafx.h"
#include "LockFreeStack.h"