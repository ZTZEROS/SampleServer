#include "stdafx.h"
#include "PDH_Profiler.h"

PDH_Profiler PDH_PROFILER;

PDH_Profiler::PDH_Profiler()
{

}

PDH_Profiler::~PDH_Profiler()
{

}

bool PDH_Profiler::Initialize()
{
	return 0;
}

bool PDH_Profiler::Update()
{
	return 0;
}

bool PDH_Profiler::Render()
{
	return 0;
}

bool PDH_Profiler::Terminalize()
{
	return 0;
}