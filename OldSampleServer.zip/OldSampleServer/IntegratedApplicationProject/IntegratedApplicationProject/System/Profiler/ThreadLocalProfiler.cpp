#include "stdafx.h"
#include "ThreadLocalProfiler.h"