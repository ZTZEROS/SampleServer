#pragma once

class JSON_Parser
{
private:

public:


};