#include "stdafx.h"
#include "LockFreeQueue.h"