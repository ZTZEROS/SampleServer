#pragma once
class BresenhamLine
{
public:
	BresenhamLine();
	~BresenhamLine();
};

