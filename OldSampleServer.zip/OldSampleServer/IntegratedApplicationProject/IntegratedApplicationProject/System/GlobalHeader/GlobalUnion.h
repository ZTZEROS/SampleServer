#pragma once

union RGB_Color
{
	DWORD RGBA;
	BYTE A; //Alpha
	BYTE B; //Blue
	BYTE G; //Green
	BYTE R; //Red
};
